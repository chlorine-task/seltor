document.addEventListener('mousemove', function(e) {
  const web = document.querySelector('.web');
  const mouseX = e.clientX;
  const mouseY = e.clientY;

  const webX = mouseX / window.innerWidth * 100;
  const webY = mouseY / window.innerHeight * 100;

  web.style.backgroundPosition = `${webX}% ${webY}%`;
});
